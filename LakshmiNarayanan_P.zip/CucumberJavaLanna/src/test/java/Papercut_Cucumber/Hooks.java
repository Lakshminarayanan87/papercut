package Papercut_Cucumber;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.junit.AfterClass;
import org.junit.BeforeClass;

/**
 * Created by User on 3/13/2017.
 */
public class Hooks {

    @BeforeClass
    public void setup(){
        DriverManager driverManager = new DriverManager();
        driverManager.openBrowser();
    }

    @AfterClass
    public void teardown(){
        DriverManager driverManager = new DriverManager();
        driverManager.closeBrowser();
    }

}
