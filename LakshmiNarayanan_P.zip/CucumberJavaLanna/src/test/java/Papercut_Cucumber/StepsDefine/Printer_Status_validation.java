package Papercut_Cucumber.StepsDefine;
import Papercut_Cucumber.ScreenShots;
import PageUtilities.PageElements;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Created by User on 3/10/2017.
 */
public class Printer_Status_validation {

    WebDriver driver;
    PageElements pageElements = new PageElements(driver);
    ScreenShots ss = new ScreenShots();
    Logger log = Logger.getLogger("PaperCut");

    // Variables / Xpath from Common Class

    private String  url                         = pageElements.url;
    private String  driver_path                 = pageElements.driver_path;
    private int     driver_wait                 = pageElements.driver_wait;
    private By      next_button                 = pageElements.next_button;
    public String   screen_shots_path           = pageElements.screen_shots_path;
    public By       google_button               = pageElements.google_button;
    public By       Email_text                  = pageElements.Email_text;
    public By       EmailNext_btn               = pageElements.EmailNext_btn;
    public By       Pass_text                   = pageElements.Pass_text;
    public By       Signin_btn                  = pageElements.Signin_btn;
    public String   Email_id                    = pageElements.Email_id;
    public String   Password                    = pageElements.Password;
    public By       Skip_tour_link              = pageElements.Skip_tour_link;
    public By       header_mail_id              = pageElements.header_mail_id;
    private String  xpath_part1                 = pageElements.xpath_part1;
    private String  xpath_part2                 = pageElements.xpath_part2;
    public By       Forecast_Button             = pageElements.Forecast_Button;
    public By       Forecast_row_count          = pageElements.Forecast_row_count;
    public String   table_row_part1             = pageElements.table_row_part1;
    public String   table_row_part2             = pageElements.table_row_part2;
    public String   table_row_part3             = pageElements.table_row_part3;
    public String   Forecast_printer_Name       = pageElements.Forecast_printer_Name;
    public By       Toner                       = pageElements.Toner;
    public By       Slider                      = pageElements.Slider;
    public By       Forecast_close              = pageElements.Forecast_close;
    public By       Sign_out                    = pageElements.Sign_out;


    /*
    *  All dependencies are Auto-Import from Maven
    *  Cucumber - BDD approach followed
    *  Links and Xpath are called from a common class - Less Maintenance when we need to change any links are Xpath
    *  Screen shots are captured and saved in local user directory inside the project
    *  Old screen shots will be deleted for every new execution
    *  HTML report generated for each execution
    *  Proper Comment and description has been given in all the Step Definition methods
    *  Screen shots are stored in :- <Projectdir>/target/TestData/Screenshot folder
    *  Links and Xpath variables are stored in PageElements utility class
    *  Added Necessary System.log for User Verification
    *  Assertion are used for validation against Expected and Actual result population
    *  Used few common methods to avoid repetitive coding
    *
    * */

    @Given("^Navigate to Papercut Webpage$")
    public void navigate_to_Papercut_Webpage() {
        System.setProperty("webdriver.chrome.driver",driver_path );
        //driver = new ChromeDriver();
        ChromeOptions chromeOptions = new ChromeOptions();
        chromeOptions.addArguments("--start-maximized");
        driver = new ChromeDriver(chromeOptions);
        driver.get(url);
        try {
            // Delete Old Screen Shots and Write New Screen shots for this Test Execution

            FileUtils.deleteDirectory(new File(screen_shots_path));
        } catch (Exception e) {
            System.out.println(e);
        }
        // Using webdriver wait untill get started button is visible
        WebDriverWait wait_nextbtn = new WebDriverWait(driver, driver_wait);
        wait_nextbtn.until(ExpectedConditions.visibilityOfElementLocated(next_button));
        ss.getscreenshot(driver,screen_shots_path+"1_Papercut.png");
        log.info("STEP 1:- Webpage Login Successful");
        log.debug("Webpage Login Success");
    }

    @When("^I click on Get Started Now button$")
    public void i_click_on_Get_Started_Now_button() {
        driver.findElement(next_button).click();
        WebDriverWait wait_glebtn = new WebDriverWait(driver, driver_wait);
        wait_glebtn.until(ExpectedConditions.visibilityOfElementLocated(google_button));
        ss.getscreenshot(driver,screen_shots_path+"2_LoginPopUp.png");
        System.out.println("STEP 2 :- Get Started Now Button Clicked");
    }
    @Then("^Do Signin using Gmail ID$")
    public void do_Signin_using_Gmail_ID(){
        driver.findElement(google_button).click(); // Clicked on Google Signin from HTML POP-UP
        driver.manage().timeouts().implicitlyWait(driver_wait, TimeUnit.SECONDS); // Implict wait as new application is opening
        driver.findElement(Email_text).sendKeys(Email_id); // SendEmail id
        ss.getscreenshot(driver,screen_shots_path+"3_EmailID.png");
        driver.findElement(EmailNext_btn).click();
        driver.findElement(Pass_text).sendKeys(Password); // SendPass
        driver.findElement(Signin_btn).click();
        System.out.println("STEP 3 :- Gmail Login Completed");
    }


    @And("^Click on Skip tour to View Dashboard$")
    public void click_on_Skip_tour_to_View_Dashboard() {
        try{
            Thread.sleep(2000);
            //WebDriverWait wait_st_link = new WebDriverWait(driver, driver_wait);
            //wait_st_link.until(ExpectedConditions.visibilityOfElementLocated(Skip_tour_link));
            ss.getscreenshot(driver,screen_shots_path+"4_SkipTour.png");
            driver.findElement(Skip_tour_link).click(); // Skip Tour link
            System.out.println("STEP 4 :- Skip Tour Clicked in Main Page");
        }
        catch (Exception e){
            System.out.println(e);
        }
    }

    @And("^Navigate to the Dashbord$")
    public void navigate_to_the_Dashbord() {
        WebDriverWait wait_mail_id_header = new WebDriverWait(driver, driver_wait);
        wait_mail_id_header.until(ExpectedConditions.visibilityOfElementLocated(header_mail_id));
        ss.getscreenshot(driver,screen_shots_path+"5_Dashboard_Navigation.png");
        System.out.println("STEP 5 :- DashBoard Loaded Successfully");

    }

    @Given("^Wait for Dashboard to load Successfully$")
    public void wait_for_Dashboard_to_load_Successfully() {
        WebDriverWait wait_mail_id_header = new WebDriverWait(driver, driver_wait);
        wait_mail_id_header.until(ExpectedConditions.visibilityOfElementLocated(header_mail_id));
        System.out.println("STEP 6 :- Login Mail Id " + Email_id);

    }
        /*
        * To validate the Status of the printer and to fetch machine name
        * Fetch/loop through all the avaliable elements from the list
        * Match of Error / Warning / Online status from gettext() method of earch loop
        * If status gets match for Error or Waning or Online -> fetch the remainng text details from the match
        * Now it is easy to get the machine name once after the extact status match from the list of rows
        *
        * I have used Webelement list to find the all webelements inside the list class
        * looping through the each line text and validate the status with machine name*/

    @Then("^Validate Email on the top right corner$")
    public void validate_Email_on_the_top_right_corner() {
        String mail_id_Fetch = driver.findElement(header_mail_id).getText();
        System.out.println("STEP 7 :- Validation 1:- Display Mail Id :" + mail_id_Fetch);
        Assert.assertEquals("Header Mail Id equals to given Mail Id",Email_id,mail_id_Fetch);
        ss.getscreenshot(driver,screen_shots_path+"6_MailId.png");
    }

    @Then("^Validate Printer Status for Online Warning and Error$")
    public void validate_Printer_Status_for_Online_Warning_and_Error() {
        List<WebElement> elements = driver.findElements(By.cssSelector(".list"));
        //int count = elements.size();

        int i = 1; // Initialise a loop
        // For loop through untill element size - iteration
        for(WebElement element:elements) {
            //System.out.println(element.getText());
            //Find the Text contenet in side Error status row
            String Printer_detail = driver.findElement(By.xpath(xpath_part1+i+xpath_part2)).getText();
            if(element.getText().contains("IN ERROR")){
                boolean Error_printer = Printer_detail.contains("Label Printer (desktop)");
                Assert.assertEquals(true, Error_printer);
                System.out.println("###############################################################");
                System.out.println("STEP 8 :- Validation 2.1:- Printer in Error Status is at Table row " +i +" Named as :"+ Printer_detail);
                System.out.println("###############################################################");
            }
            if(element.getText().contains("WARNING")){
                //System.out.println("Warning Text Are " + Printer_detail);
                boolean Warning_Printer = Printer_detail.contains("A3 Printer (server)");
                Assert.assertEquals(true, Warning_Printer);
                System.out.println("###############################################################");
                System.out.println("STEP 9:- Validation 2.2:- Printer in Warning Status is at Table row " +i +" Named as :"+ Printer_detail);
                System.out.println("###############################################################");
            }

            if(element.getText().contains("Online")){
                //System.out.println("Online Text Are " + Printer_detail);
                boolean Online_printer = Printer_detail.contains("Reception Printer (server)");
                Assert.assertEquals(true, Online_printer);
                System.out.println("###############################################################");
                System.out.println("STEP 10:- Validation 2.3:- Printer in Online Status is at Table row " +i +" Named as :"+ Printer_detail);
                System.out.println("###############################################################");
            }
            i++;
        }

    }

    @Then("^Validate Number of Page This Month$")
    public void validate_Number_of_Page_This_Month(){

        List<WebElement> Month_Sum =driver.findElements(By.xpath("//span[contains(@class,'num') and contains(@class,'big')]")); //cssSelector(".num.big']")); // className("num big"));
        for(int Mon_index=2;Mon_index<Month_Sum.size();Mon_index++)
        {//Month of page is 3rd value of Num.Big class ; So fetch 3rd value from the loop directly i.e arr[2]
            System.out.println("STEP 11:- Validation 3:- Pages This Month "+Month_Sum.get(2).getText());

        }

    }

    @Then("^Navigate to Forecast Page$")
    public void Navigate_to_Forecast_Page() {
        // Clicking on Forecast Button
        driver.findElement(Forecast_Button).click();
        System.out.println("STEP 12:- Clicking on Forecast Button");
        ss.getscreenshot(driver,screen_shots_path+"8_Forecast_window.png");
    }

    @Then("^Validate number of HP Color Laser at Forecast$")
    public void validate_number_of_HP_Color_Laser_at_Forecast() {
        String arr[]=read_Consumption(Forecast_printer_Name); // Sending Given Printer Value to fetch Model Details
        System.out.println("STEP 13:- Validation 4:- For Printer"+Forecast_printer_Name + " Next 30 Days Data"+
                                                        "\n Cyan -----"    +arr[2]+
                                                        "\n Magenta --"    +arr[3] +
                                                        "\n Yellow ---"    +arr[4]+
                                                        "\n Black-----"    +arr[5]);
        ss.getscreenshot(driver,screen_shots_path+"9_30Day_Forecast.png");
    }

    @Then("^Click on given days in Forecast window$")
    public void click_on_given_days_in_Forecast_window(){
        try{
            //Thread.sleep(2000);
            List<WebElement> lst_toner=driver.findElements(Toner);
            //System.out.println(lst_toner.size());
            //Fetching toner size to loop the table and match the given printer name from the table size
            //for(int findex=0;findex<lst_toner.size();findex++)
            //{
                driver.findElement(Slider).click(); // Click on 60 days in Slider
                driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
                String arr[] = read_Consumption(Forecast_printer_Name); // Sending Given Printer Value to fetch Model Details
                System.out.println("STEP 14:- Validation 5:- For Printer"+Forecast_printer_Name + " Next 60 Days Data"+
                                                                  "\n Cyan -----"    +arr[2]+
                                                                  "\n Magenta --"    +arr[3] +
                                                                  "\n Yellow ---"    +arr[4]+
                                                                  "\n Black-----"    +arr[5]);
                ss.getscreenshot(driver,screen_shots_path+"10_60Day_Forecast.png");
            //}
        }
        catch (Exception e){
            System.out.println(e);
        }


    }

    @Then("^Close the window and Signout$")
    public void close_the_window_and_Signout() {
        try {
            Thread.sleep(2000);
            driver.findElement(Forecast_close).click();
            ss.getscreenshot(driver,screen_shots_path+"11_Toner_Ink_Close.png");

            // Java script element - Clicking on Header Mail id and navigate to Sign-out click
            WebElement element = driver.findElement(header_mail_id);
            JavascriptExecutor executor = (JavascriptExecutor)driver;
            executor.executeScript("arguments[0].click();", element);
            ss.getscreenshot(driver,screen_shots_path+"12_Signout.png");

            driver.findElement(Sign_out).click();
            System.out.println("STEP15:- Validation 6:- Signout Succesfully");
            driver.quit();
        }
        catch (Exception e){
            System.out.println(e);
        }
        // Close Forecast Window & Signout
    }

    /*
    * Common Methdod to Read Forecast Table Content
    * Input as Model Name
    * Returns :- Table data in string array
    * */

    public String[] read_Consumption(String Model_Name){
        int rowCount=driver.findElements(Forecast_row_count).size();
        int tbl_row =1, tbl_col=1;
        String xpath_str = null;
        int n = 10;
        String[] arr = new String[n];
        arr[0]="";

        for(tbl_row=1; tbl_row<=rowCount;tbl_row++){
            xpath_str=table_row_part1+tbl_row+table_row_part2+tbl_col+table_row_part3;
            String text_value = driver.findElement(By.xpath(xpath_str)).getText();
            //System.out.println("Table Data"+ tbl_row + text_value);
            if(text_value.equalsIgnoreCase(Forecast_printer_Name)){
                // fetch details for 5 cloumns ( from 15+)
                for(tbl_col=1;tbl_col<=5;tbl_col++){
                    xpath_str=table_row_part1+tbl_row+table_row_part2+tbl_col+table_row_part3;
                    String col_value = driver.findElement(By.xpath(xpath_str)).getText();
                    arr[tbl_col] = col_value;
                    //System.out.println("Table Column"+ tbl_col + col_value + arr[0] + arr[tbl_col]);
                }
            }
        }
        return arr;
    }
}

