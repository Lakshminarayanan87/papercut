package Papercut_Cucumber.StepsDefine;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

/**
 * Created by User on 3/13/2017.
 */


@RunWith(Cucumber.class)
//@CucumberOptions(features = "C:\\Users\\User\\IdeaProjects\\CucumberJavaLanna\\src\\test\\resources\\features")
// , format = { "pretty","html:\\Users\\User\\IdeaProjects\\CucumberJavaLanna\\target" })
@CucumberOptions(features = "." , tags = "@Papercut_Automation" , format = {"pretty","html:\\Users\\User\\IdeaProjects\\CucumberJavaLanna\\target"})

public class RunTest_Automation {
}
