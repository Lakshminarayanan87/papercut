package PageUtilities;

import com.gargoylesoftware.htmlunit.Page;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by User on 3/13/2017.
 */
public class PageElements {

    WebDriver driver;

    public PageElements ( WebDriver w){
        driver = w;
    }
    public String workingDirectory          = System.getProperty("user.dir");
    public String testDatadir               = workingDirectory+"\\src\\test\\TestRepo\\";
    public String report_path               = workingDirectory+"\\target\\TestData\\";
    public String driver_path               = report_path+"chromedriver.exe";// "C:\\Tools\\chromedriver_win32\\chromedriver.exe";
    public String screen_shots_path         = report_path+"Screenshot\\" ;//"C:\\Users\\User\\Desktop\\Screenshots\\";
    public int driver_wait                  = 10;

    public String url                       = "https://views.papercut.com/";
    public By next_button                   = By.cssSelector("a[href*='#next']");
    public By google_button                 = By.xpath("html/body/div[2]/div/div/div[3]/ul/li[1]/a/span");

    public By Email_text                    = By.xpath(".//*[@id='Email']");
    public By EmailNext_btn                 = By.xpath(".//*[@id='next']");
    public By Pass_text                     = By.xpath(".//*[@id='Passwd']");
    public By Signin_btn                    = By.xpath(".//*[@id='signIn']");
    public String Email_id                  = "lakshmi87test@gmail.com";
    public String Password                  = "lakshmi87";

    public By Skip_tour_link                = By.xpath(".//*[@id='rpf']/div/div/div[2]/h4/asside/div/footer/a[2]");
    public By header_mail_id                = By.xpath(".//*[@id='header']/div[1]/ul/li[2]/a/div/span");
    public By check_end                     = By.xpath(".//*[@id='recent-jobs']/div[2]/span");
    public String xpath_part1               =".//*[@id='device-list']/div/div/div[";
    public String xpath_part2               ="]";

    //Forecast Page
    public By Forecast_Button               = By.xpath(".//*[@id='forecasts']/div/div/div[1]/div[1]/div/div[2]/button");
    public By Forecast_row_count            = By.xpath(".//*[@id='modal-toner']/div/div[2]/div/div/table/tbody/tr");
    public String table_row_part1           =".//*[@id='modal-toner']/div/div[2]/div/div/table/tbody/tr[";
    public String table_row_part2           ="]/td[";
    public String table_row_part3           ="]";
    public String Forecast_printer_Name     = "1x HP Color LaserJet Pro MFP M277 PCL6";
    public By Toner                         = By.xpath(".//*[@id='modal-toner']/div/div[1]/p");
    public By Slider                        = By.xpath(".//*[@id='modal-toner']/div/div[1]/div/ul/li[2]");
    public By Forecast_close                = By.xpath(".//*[@id='modal-toner']/header/i/span");
    public By Header_link                   = By.xpath(".//*[@id='header']/div[1]/ul/li[2]/a");
    public By Sign_out                      = By.xpath(".//*[@id='header']/div[2]/ul/li[3]/a");

}
