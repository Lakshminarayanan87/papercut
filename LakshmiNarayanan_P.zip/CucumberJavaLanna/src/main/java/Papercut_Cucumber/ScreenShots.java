package Papercut_Cucumber;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;

/**
 * Created by User on 3/13/2017.
 */
public class ScreenShots {

    public void getscreenshot(WebDriver driver, String location) {

        // generate screenshot as a file object
        File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        try {
            // copy file object to location ( File Path)
            FileUtils.copyFile(scrFile, new File(location));
        } catch (IOException e) {
            System.out.println("Error while generating screenshot:\n" + e.toString());
        }
    }
}
